# WireSpec cross-IDE companions v0.5

## Intent

This package makes the IDE layer thinner and keeps the review workflow more stable: one shared core now owns discovery, next-task selection, save-driven thread resolution, and audit-log writes, while VS Code and JetBrains wrappers only translate editor events into core CLI calls.

## Implementation

Included here:

- `packages/core` — shared Node core and CLI
- `packages/vscode` — thin VS Code companion that shells into the core
- `packages/jetbrains` — thin IntelliJ Platform companion skeleton that shells into the same core
- `demo-workspace` — realistic review/task fixture
- `outputs` — generated transcripts and JSON examples

## Explain-back

- The business logic is now centralized instead of duplicated across IDEs.
- The JetBrains layer stays intentionally small: status bar widget, actions, listeners, no dashboard shell.
- The same JSON command contract drives both editors.
- Review resolution now targets edited implementation files, not just the WireSpec source.
- Audit events stay consistent because only the shared core writes them.

## Verification checklist

Run from this folder:

```bash
npm test
npm run generate:examples
```

Expected outcomes:

- tests pass
- `outputs/*.json` files are regenerated
- `outputs/cross-ide-simulation.transcript.txt` shows the same core flow for VS Code and JetBrains
- `outputs/ide.events.ndjson` contains `task-file-changed` and `threads-resolved` records

## Audit artifact

What changed:

- added a shared cross-IDE core with CLI entrypoints
- rewired the VS Code companion to call the core instead of holding its own business logic
- added a JetBrains thin companion skeleton with project service, VFS/document listeners, status bar widget, and actions
- shifted fixture targets to implementation files so save-driven resolution matches real agent work

How to debug later:

- if a task does not resolve on save, check that the thread has a `source-span` anchor pointing at the edited file
- if JetBrains cannot talk to the core, verify the configured Node executable and `packages/core/bin/wirespec-ide-core.js` path
- if auto-open feels noisy, disable the relevant companion setting before expanding the UI surface
