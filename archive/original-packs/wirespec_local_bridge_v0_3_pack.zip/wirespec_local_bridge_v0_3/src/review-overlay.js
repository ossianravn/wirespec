import { escapeHtml } from "./shared.js";

const css = `
.ws-review-bar {
  position: fixed;
  top: 16px;
  right: 16px;
  z-index: 10000;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  border: 1px solid rgba(17,17,17,0.12);
  border-radius: 14px;
  background: rgba(255,255,255,0.98);
  color: #111;
  box-shadow: 0 8px 20px rgba(17,17,17,0.08);
  font: 500 14px/1.2 Inter, ui-sans-serif, system-ui, sans-serif;
}
.ws-review-bar button {
  appearance: none;
  border: 1px solid rgba(17,17,17,0.16);
  background: #fff;
  color: #111;
  border-radius: 10px;
  min-height: 34px;
  padding: 0 12px;
  font: inherit;
  cursor: pointer;
}
.ws-review-bar button[aria-pressed="true"],
.ws-review-bar button[data-primary="true"] {
  background: #111;
  border-color: #111;
  color: #fff;
}
.ws-review-bar-meta {
  color: rgba(17,17,17,0.66);
  white-space: nowrap;
}
.ws-review-active [data-ws-target] {
  cursor: crosshair;
}
.ws-review-active [data-ws-target]:hover {
  outline: 2px solid rgba(17,17,17,0.28);
  outline-offset: 2px;
}
.ws-review-composer,
.ws-review-drawer {
  position: fixed;
  right: 16px;
  width: min(380px, calc(100vw - 32px));
  z-index: 10001;
  border: 1px solid rgba(17,17,17,0.12);
  border-radius: 14px;
  background: rgba(255,255,255,0.98);
  color: #111;
  box-shadow: 0 10px 24px rgba(17,17,17,0.08);
  font: 400 14px/1.4 Inter, ui-sans-serif, system-ui, sans-serif;
}
.ws-review-composer {
  bottom: 16px;
  padding: 12px;
}
.ws-review-drawer {
  top: 64px;
  bottom: 16px;
  display: none;
  overflow: hidden;
  flex-direction: column;
}
.ws-review-drawer.is-open {
  display: flex;
}
.ws-review-drawer-header,
.ws-review-drawer-footer {
  padding: 12px;
  border-bottom: 1px solid rgba(17,17,17,0.08);
}
.ws-review-drawer-footer {
  border-top: 1px solid rgba(17,17,17,0.08);
  border-bottom: 0;
}
.ws-review-drawer-body {
  padding: 12px;
  overflow: auto;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.ws-review-drawer h2,
.ws-review-composer h2,
.ws-review-card h3,
.ws-review-card p,
.ws-review-composer p,
.ws-review-empty p {
  margin: 0;
}
.ws-review-label,
.ws-review-meta,
.ws-review-empty {
  color: rgba(17,17,17,0.66);
}
.ws-review-card {
  border: 1px solid rgba(17,17,17,0.10);
  border-radius: 12px;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: #fff;
}
.ws-review-card-head,
.ws-review-card-actions {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.ws-review-card-head {
  justify-content: space-between;
}
.ws-review-chip {
  display: inline-flex;
  align-items: center;
  min-height: 24px;
  padding: 0 8px;
  border-radius: 999px;
  border: 1px solid rgba(17,17,17,0.12);
  font-size: 12px;
  line-height: 1;
}
.ws-review-chip[data-severity="must"] {
  background: #111;
  border-color: #111;
  color: #fff;
}
.ws-review-composer label {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-top: 10px;
}
.ws-review-composer input,
.ws-review-composer select,
.ws-review-composer textarea {
  width: 100%;
  border: 1px solid rgba(17,17,17,0.14);
  border-radius: 10px;
  padding: 10px 12px;
  background: #fff;
  color: #111;
  font: inherit;
}
.ws-review-composer textarea {
  min-height: 104px;
  resize: vertical;
}
.ws-review-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 12px;
}
.ws-review-actions button,
.ws-review-drawer button {
  appearance: none;
  border: 1px solid rgba(17,17,17,0.16);
  background: #fff;
  color: #111;
  border-radius: 10px;
  min-height: 34px;
  padding: 0 10px;
  font: inherit;
  cursor: pointer;
}
.ws-review-drawer button[data-primary="true"],
.ws-review-actions button[data-primary="true"] {
  background: #111;
  border-color: #111;
  color: #fff;
}
.ws-review-pin {
  position: absolute;
  top: 8px;
  right: 8px;
  min-width: 22px;
  min-height: 22px;
  border-radius: 999px;
  border: 1px solid rgba(17,17,17,0.12);
  background: rgba(17,17,17,0.9);
  color: #fff;
  font: 600 12px/1 Inter, ui-sans-serif, system-ui, sans-serif;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}
.ws-review-highlight {
  outline: 3px solid rgba(17,17,17,0.22) !important;
  outline-offset: 4px !important;
}
@media (max-width: 767px) {
  .ws-review-bar {
    left: 12px;
    right: 12px;
    width: auto;
    justify-content: space-between;
  }
  .ws-review-drawer {
    left: 12px;
    right: 12px;
    width: auto;
    top: auto;
    bottom: 12px;
    max-height: 72vh;
  }
  .ws-review-composer {
    left: 12px;
    right: 12px;
    width: auto;
  }
}
`;

function ensureStyle() {
  if (document.getElementById("ws-review-overlay-style")) {
    return;
  }
  const style = document.createElement("style");
  style.id = "ws-review-overlay-style";
  style.textContent = css;
  document.head.append(style);
}

function lookupTarget(sourceMap, targetId, element) {
  const match = sourceMap?.targets?.find((entry) => entry.targetId === targetId);
  if (match) {
    return {
      targetId,
      label: match.label || match.wireId || match.kind,
      scope: match.scope,
      kind: match.kind,
    };
  }
  return {
    targetId,
    label: element?.getAttribute("data-ws-id") || element?.getAttribute("data-ws-kind") || targetId,
    scope: element?.getAttribute("data-ws-id") ? "element" : "section",
    kind: element?.getAttribute("data-ws-kind") || "node",
  };
}

function closestTarget(element) {
  let current = element;
  while (current) {
    if (current.hasAttribute?.("data-ws-target")) {
      return current;
    }
    current = current.parentElement;
  }
  return null;
}

function parentTarget(element) {
  const current = closestTarget(element);
  if (!current) {
    return null;
  }
  return closestTarget(current.parentElement);
}

export function mountReviewOverlay(options) {
  ensureStyle();

  let commentMode = !!options.commentModeDefault;
  let threads = options.getThreads ? options.getThreads() : [];
  let bridgeLabel = "bridge off";
  let bridgeTone = "muted";
  let activeHighlight = null;
  let composer = null;

  const bar = document.createElement("aside");
  bar.className = "ws-review-bar";
  bar.innerHTML = `
    <button type="button" data-action="comment" aria-pressed="${commentMode ? "true" : "false"}">Review</button>
    <button type="button" data-action="threads">Threads</button>
    <button type="button" data-action="save" data-primary="true">Save</button>
    <span class="ws-review-bar-meta" data-role="status">${escapeHtml(bridgeLabel)}</span>
  `;
  document.body.append(bar);

  const drawer = document.createElement("aside");
  drawer.className = "ws-review-drawer";
  document.body.append(drawer);

  function setHighlight(targetElement) {
    if (activeHighlight) {
      activeHighlight.classList.remove("ws-review-highlight");
    }
    activeHighlight = targetElement || null;
    activeHighlight?.classList.add("ws-review-highlight");
  }

  function openDrawer(focusTargetId) {
    drawer.classList.add("is-open");
    renderDrawer(focusTargetId);
  }

  function closeDrawer() {
    drawer.classList.remove("is-open");
  }

  function closeComposer() {
    composer?.remove();
    composer = null;
    setHighlight(null);
  }

  function renderPins() {
    document.querySelectorAll(".ws-review-pin").forEach((node) => node.remove());
    const counts = new Map();
    for (const thread of threads) {
      if (thread.status === "resolved" || thread.status === "wontfix") {
        continue;
      }
      counts.set(thread.target.targetId, (counts.get(thread.target.targetId) || 0) + 1);
    }
    for (const [targetId, count] of counts.entries()) {
      const element = document.querySelector(`[data-ws-target="${CSS.escape(targetId)}"]`);
      if (!element) {
        continue;
      }
      const pin = document.createElement("button");
      pin.type = "button";
      pin.className = "ws-review-pin";
      pin.textContent = String(count);
      pin.title = `${count} open review notes`;
      pin.addEventListener("click", (event) => {
        event.stopPropagation();
        openDrawer(targetId);
      });
      const computedStyle = window.getComputedStyle(element);
      if (computedStyle.position === "static") {
        element.style.position = "relative";
      }
      element.append(pin);
    }
  }

  function renderDrawer(focusTargetId) {
    const filtered = focusTargetId
      ? threads.filter((thread) => thread.target.targetId === focusTargetId)
      : threads;

    const cards = filtered.length
      ? filtered
          .map((thread) => {
            const latest = thread.messages[thread.messages.length - 1]?.body || "";
            const targetLabel = thread.target.wireId || thread.target.targetId;
            const statusButtons =
              thread.status === "resolved"
                ? `<button type="button" data-thread-action="reopen" data-thread-id="${escapeHtml(thread.id)}">Reopen</button>`
                : `<button type="button" data-thread-action="resolve" data-thread-id="${escapeHtml(thread.id)}">Resolve</button>
                   <button type="button" data-thread-action="wontfix" data-thread-id="${escapeHtml(thread.id)}">Won't fix</button>`;
            return `
              <article class="ws-review-card" data-thread-id="${escapeHtml(thread.id)}">
                <div class="ws-review-card-head">
                  <div>
                    <h3>${escapeHtml(thread.title)}</h3>
                    <p class="ws-review-meta">${escapeHtml(targetLabel)}${thread.target.variantKey ? ` · ${escapeHtml(thread.target.variantKey)}` : ""}</p>
                  </div>
                  <span class="ws-review-chip" data-severity="${escapeHtml(thread.severity)}">${escapeHtml(thread.severity)}</span>
                </div>
                <p>${escapeHtml(latest)}</p>
                <div class="ws-review-card-actions">
                  <span class="ws-review-chip">${escapeHtml(thread.status)}</span>
                  ${statusButtons}
                </div>
              </article>
            `;
          })
          .join("")
      : `<div class="ws-review-empty"><p>No review notes yet.</p></div>`;

    drawer.innerHTML = `
      <div class="ws-review-drawer-header">
        <h2>Review threads</h2>
        <p class="ws-review-label">${threads.length} total · ${threads.filter((thread) => thread.status === "open" || thread.status === "in_progress").length} open</p>
      </div>
      <div class="ws-review-drawer-body">${cards}</div>
      <div class="ws-review-drawer-footer">
        <button type="button" data-action="close-drawer">Close</button>
      </div>
    `;

    drawer.querySelector('[data-action="close-drawer"]')?.addEventListener("click", closeDrawer);
    drawer.querySelectorAll("[data-thread-action]").forEach((button) => {
      button.addEventListener("click", () => {
        options.onStatusChange?.({
          threadId: button.getAttribute("data-thread-id"),
          status: button.getAttribute("data-thread-action") === "resolve"
            ? "resolved"
            : button.getAttribute("data-thread-action") === "reopen"
              ? "open"
              : "wontfix",
        });
      });
    });
  }

  function showComposer(target) {
    closeComposer();
    composer = document.createElement("section");
    composer.className = "ws-review-composer";
    composer.innerHTML = `
      <div>
        <h2>New review note</h2>
        <p class="ws-review-label">${escapeHtml(target.scope)} · ${escapeHtml(target.kind)} · ${escapeHtml(target.label)}</p>
      </div>
      <label>
        <span>Title</span>
        <input name="title" type="text" placeholder="Summarize the change">
      </label>
      <label>
        <span>Severity</span>
        <select name="severity">
          <option value="must">Must</option>
          <option value="should" selected>Should</option>
          <option value="could">Could</option>
          <option value="question">Question</option>
        </select>
      </label>
      <label>
        <span>Comment</span>
        <textarea name="body" placeholder="Describe what should change and why."></textarea>
      </label>
      <div class="ws-review-actions">
        <button type="button" data-action="cancel">Cancel</button>
        <button type="button" data-action="submit" data-primary="true" disabled>Create note</button>
      </div>
    `;
    document.body.append(composer);

    const title = composer.querySelector('input[name="title"]');
    const severity = composer.querySelector('select[name="severity"]');
    const body = composer.querySelector('textarea[name="body"]');
    const submit = composer.querySelector('[data-action="submit"]');

    const sync = () => {
      submit.disabled = !body.value.trim();
    };

    composer.querySelector('[data-action="cancel"]')?.addEventListener("click", closeComposer);
    body?.addEventListener("input", sync);
    submit?.addEventListener("click", () => {
      if (!body.value.trim()) {
        return;
      }
      options.onDraftSubmitted?.({
        targetId: target.targetId,
        title: title.value.trim() || `Review ${target.label}`,
        severity: severity.value,
        category: "ux",
        body: body.value.trim(),
      });
      closeComposer();
      openDrawer(target.targetId);
    });
  }

  function onDocumentClick(event) {
    if (!commentMode) {
      return;
    }
    if (bar.contains(event.target) || drawer.contains(event.target) || composer?.contains(event.target)) {
      return;
    }
    const targetElement = event.altKey ? parentTarget(event.target) : closestTarget(event.target);
    if (!targetElement) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    const targetId = targetElement.getAttribute("data-ws-target");
    const target = lookupTarget(options.sourceMap, targetId, targetElement);
    setHighlight(targetElement);
    showComposer(target);
  }

  document.body.classList.toggle("ws-review-active", commentMode);
  document.addEventListener("click", onDocumentClick, true);

  bar.querySelector('[data-action="comment"]')?.addEventListener("click", () => {
    commentMode = !commentMode;
    document.body.classList.toggle("ws-review-active", commentMode);
    bar.querySelector('[data-action="comment"]')?.setAttribute("aria-pressed", commentMode ? "true" : "false");
    if (!commentMode) {
      closeComposer();
    }
  });

  bar.querySelector('[data-action="threads"]')?.addEventListener("click", () => {
    if (drawer.classList.contains("is-open")) {
      closeDrawer();
    } else {
      openDrawer();
    }
  });

  bar.querySelector('[data-action="save"]')?.addEventListener("click", async () => {
    const button = bar.querySelector('[data-action="save"]');
    const previous = button.textContent;
    button.textContent = "Saving…";
    button.disabled = true;
    try {
      await options.onSaveRequested?.();
    } finally {
      button.textContent = previous;
      button.disabled = false;
    }
  });

  renderDrawer();
  renderPins();

  return {
    setThreads(nextThreads) {
      threads = nextThreads;
      renderPins();
      if (drawer.classList.contains("is-open")) {
        renderDrawer();
      }
    },
    setBridgeState(nextState) {
      bridgeLabel = nextState.label || bridgeLabel;
      bridgeTone = nextState.tone || bridgeTone;
      const node = bar.querySelector('[data-role="status"]');
      if (node) {
        node.textContent = bridgeLabel;
        node.dataset.tone = bridgeTone;
      }
    },
    flashMessage(message) {
      const node = bar.querySelector('[data-role="status"]');
      if (node) {
        node.textContent = message;
      }
    },
    openDrawer,
    closeDrawer,
    dispose() {
      document.removeEventListener("click", onDocumentClick, true);
      closeComposer();
      drawer.remove();
      bar.remove();
      document.querySelectorAll(".ws-review-pin").forEach((node) => node.remove());
      if (activeHighlight) {
        activeHighlight.classList.remove("ws-review-highlight");
      }
    },
  };
}
