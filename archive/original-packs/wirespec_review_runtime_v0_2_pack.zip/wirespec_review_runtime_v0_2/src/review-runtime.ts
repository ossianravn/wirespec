import {
  AnnotationSidecar,
  AgentTaskExport,
  ReviewDraft,
  ReviewStore,
  ReviewThread,
  SourceMapDocument,
} from "./types.js";
import {
  createReviewThreadFromDraft,
  relinkStoreAgainstSourceMap,
  reviewStoreToSidecar,
  sidecarToReviewStore,
  summarizeThread,
} from "./annotation-sidecar.js";
import { buildEditorOpenRequest } from "./editor-links.js";
import { mountReviewOverlay } from "./review-overlay.js";
import {
  addThread,
  activeThreadCount,
  createEmptyReviewStore,
  reviewCounts,
  updateThreadStatus,
} from "./review-store.js";
import { exportAgentTasks } from "./task-export.js";
import { escapeHtml } from "./utils.js";

export interface ReviewRuntimeOptions {
  sourceMap: SourceMapDocument;
  variantKey?: string;
  workspaceRoot?: string;
  authorId?: string;
  authorRole?: "human" | "agent" | "system";
  initialStore?: ReviewStore;
  initialSidecar?: AnnotationSidecar;
  storageKey?: string | false;
  commentModeDefault?: boolean;
}

export interface ReviewRuntimeController {
  dispose: () => void;
  getStore: () => ReviewStore;
  getSidecar: () => AnnotationSidecar;
  getAgentTasks: () => AgentTaskExport;
  openDrawer: (targetId?: string) => void;
  closeDrawer: () => void;
  replaceStore: (store: ReviewStore) => void;
}

const runtimeCss = `
.ws-review-drawer {
  position: fixed;
  top: 64px;
  right: 16px;
  bottom: 16px;
  width: min(380px, calc(100vw - 32px));
  z-index: 10001;
  display: none;
  flex-direction: column;
  background: rgba(255,255,255,0.98);
  border: 1px solid rgba(17,17,17,0.12);
  border-radius: 16px;
  box-shadow: 0 18px 44px rgba(17,17,17,0.12);
  color: #111;
  overflow: hidden;
  font: 400 14px/1.4 Inter, ui-sans-serif, system-ui, sans-serif;
}
.ws-review-drawer.is-open {
  display: flex;
}
.ws-review-drawer-header,
.ws-review-drawer-footer {
  padding: 12px;
  border-bottom: 1px solid rgba(17,17,17,0.08);
}
.ws-review-drawer-footer {
  border-bottom: 0;
  border-top: 1px solid rgba(17,17,17,0.08);
}
.ws-review-drawer-title-row,
.ws-review-drawer-filter,
.ws-review-export-actions,
.ws-review-thread-actions {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
}
.ws-review-drawer-title-row {
  justify-content: space-between;
}
.ws-review-drawer-title {
  margin: 0;
  font-size: 15px;
  font-weight: 600;
}
.ws-review-drawer-meta,
.ws-review-thread-meta,
.ws-review-thread-target,
.ws-review-empty,
.ws-review-thread-orphaned {
  color: rgba(17,17,17,0.68);
}
.ws-review-drawer-header p,
.ws-review-thread-card p,
.ws-review-thread-card h3 {
  margin: 0;
}
.ws-review-drawer-body {
  overflow: auto;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.ws-review-thread-card {
  border: 1px solid rgba(17,17,17,0.12);
  border-radius: 12px;
  padding: 12px;
  background: #fff;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.ws-review-thread-card[data-orphaned="true"] {
  border-style: dashed;
}
.ws-review-thread-head {
  display: flex;
  justify-content: space-between;
  gap: 8px;
  align-items: flex-start;
}
.ws-review-thread-title {
  font-size: 14px;
  font-weight: 600;
}
.ws-review-pill,
.ws-review-severity-pill,
.ws-review-status-pill {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 24px;
  padding: 0 8px;
  border-radius: 999px;
  border: 1px solid rgba(17,17,17,0.12);
  background: #fff;
  color: #111;
  white-space: nowrap;
  font-size: 12px;
  line-height: 1;
}
.ws-review-severity-pill[data-severity="must"] {
  background: #111;
  border-color: #111;
  color: #fff;
}
.ws-review-severity-pill[data-severity="should"] {
  background: #f3f3f3;
}
.ws-review-severity-pill[data-severity="could"],
.ws-review-severity-pill[data-severity="question"] {
  color: rgba(17,17,17,0.72);
}
.ws-review-drawer button,
.ws-review-drawer a,
.ws-review-bar [data-ws-review-runtime-button] {
  appearance: none;
  border: 1px solid rgba(17,17,17,0.16);
  background: #fff;
  color: #111;
  border-radius: 10px;
  min-height: 34px;
  padding: 0 10px;
  font: inherit;
  cursor: pointer;
  text-decoration: none;
}
.ws-review-drawer button[data-primary="true"] {
  background: #111;
  border-color: #111;
  color: #fff;
}
.ws-review-filter-chip[aria-pressed="true"] {
  background: #111;
  border-color: #111;
  color: #fff;
}
.ws-review-pin {
  position: absolute;
  top: 8px;
  right: 8px;
  z-index: 5;
  min-width: 24px;
  min-height: 24px;
  padding: 0 6px;
  border: 1px solid rgba(17,17,17,0.12);
  border-radius: 999px;
  background: rgba(17,17,17,0.92);
  color: #fff;
  font: 600 12px/1 Inter, ui-sans-serif, system-ui, sans-serif;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}
.ws-review-target-highlight {
  outline: 3px solid rgba(17,17,17,0.28) !important;
  outline-offset: 4px !important;
}
@media (max-width: 767px) {
  .ws-review-drawer {
    inset: auto 12px 12px 12px;
    top: auto;
    width: auto;
    max-height: 72vh;
  }
}
`;

function ensureRuntimeStyle(): void {
  if (document.getElementById("ws-review-runtime-style")) {
    return;
  }
  const style = document.createElement("style");
  style.id = "ws-review-runtime-style";
  style.textContent = runtimeCss;
  document.head.append(style);
}

function storageFor(key: string | false): Storage | null {
  if (!key) {
    return null;
  }
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

function makeButton(label: string): HTMLButtonElement {
  const element = document.createElement("button");
  element.type = "button";
  element.textContent = label;
  return element;
}

function selectorForTarget(targetId: string): string {
  const safe = targetId.replaceAll("\\", "\\\\").replaceAll('"', '\\"');
  return `[data-ws-target="${safe}"]`;
}

function downloadJson(filename: string, payload: unknown): void {
  const blob = new Blob([`${JSON.stringify(payload, null, 2)}\n`], {
    type: "application/json",
  });
  const href = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = href;
  anchor.download = filename;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(href), 0);
}

function latestMessage(thread: ReviewThread): string {
  return thread.messages[thread.messages.length - 1]?.body ?? "";
}

function scopeLabel(scope: ReviewThread["target"]["scope"]): string {
  switch (scope) {
    case "screen":
      return "page";
    case "section":
      return "section";
    case "element":
      return "element";
    case "prose":
      return "prose";
    case "acceptance":
      return "acceptance";
    case "region":
      return "region";
  }
}

function statusActionLabel(thread: ReviewThread): string {
  return thread.status === "resolved" || thread.status === "wontfix"
    ? "Reopen"
    : "Resolve";
}

function nextStatus(thread: ReviewThread): ReviewThread["status"] {
  return thread.status === "resolved" || thread.status === "wontfix" ? "open" : "resolved";
}

function editorUri(
  sourceMap: SourceMapDocument,
  thread: ReviewThread,
  workspaceRoot?: string,
): string | undefined {
  const target = sourceMap.targets.find((entry) => entry.targetId === thread.target.targetId);
  if (!target) {
    return undefined;
  }
  return buildEditorOpenRequest(target.span, workspaceRoot).location.uri;
}

function labelForTarget(sourceMap: SourceMapDocument, targetId: string): string {
  const target = sourceMap.targets.find((entry) => entry.targetId === targetId);
  return target?.label ?? target?.wireId ?? target?.kind ?? targetId;
}

export function mountReviewRuntime(options: ReviewRuntimeOptions): ReviewRuntimeController {
  ensureRuntimeStyle();

  const variantKey = options.variantKey ?? "base";
  const storageKey =
    options.storageKey === false
      ? false
      : options.storageKey ?? `wirespec.review.${options.sourceMap.documentId}`;
  const storage = storageFor(storageKey);
  const screenId =
    options.sourceMap.targets.find((target) => target.scope === "screen")?.screenId ??
    options.sourceMap.documentId;

  const readInitialStore = (): ReviewStore => {
    if (storage && storageKey) {
      try {
        const raw = storage.getItem(storageKey);
        if (raw) {
          return sidecarToReviewStore(JSON.parse(raw) as AnnotationSidecar, options.sourceMap);
        }
      } catch {
        // ignore invalid persisted data
      }
    }
    if (options.initialSidecar) {
      return sidecarToReviewStore(options.initialSidecar, options.sourceMap);
    }
    if (options.initialStore) {
      return relinkStoreAgainstSourceMap(options.initialStore, options.sourceMap);
    }
    return createEmptyReviewStore(options.sourceMap.documentId, screenId);
  };

  let store = readInitialStore();
  let filterTargetId: string | undefined;
  let showClosed = false;
  let drawerOpen = false;
  let highlightedElement: HTMLElement | null = null;

  const cleanupOverlay = mountReviewOverlay({
    sourceMap: options.sourceMap,
    commentModeDefault: options.commentModeDefault,
  });

  const bar = document.querySelector(".ws-review-bar") as HTMLDivElement | null;
  const actionSlot = bar?.querySelector("[data-ws-review-bar-actions]") as HTMLDivElement | null;
  const threadsButton = makeButton(`Threads (${activeThreadCount(store)})`);
  threadsButton.setAttribute("data-ws-review-runtime-button", "threads");
  actionSlot?.append(threadsButton);

  const drawer = document.createElement("aside");
  drawer.className = "ws-review-drawer";
  drawer.setAttribute("aria-label", "Review threads");
  drawer.innerHTML = `
    <div class="ws-review-drawer-header">
      <div class="ws-review-drawer-title-row">
        <div>
          <h2 class="ws-review-drawer-title">Review threads</h2>
          <p class="ws-review-drawer-meta" data-role="meta"></p>
        </div>
        <button type="button" data-action="close">Close</button>
      </div>
      <div class="ws-review-drawer-filter">
        <button type="button" class="ws-review-filter-chip" data-filter="active" aria-pressed="true">Active</button>
        <button type="button" class="ws-review-filter-chip" data-filter="all" aria-pressed="false">All</button>
        <span class="ws-review-drawer-meta" data-role="filter-target"></span>
      </div>
    </div>
    <div class="ws-review-drawer-body" data-role="body"></div>
    <div class="ws-review-drawer-footer">
      <div class="ws-review-export-actions">
        <button type="button" data-action="export-annotations" data-primary="true">Annotations JSON</button>
        <button type="button" data-action="export-tasks">Agent tasks</button>
        <button type="button" data-action="import">Import</button>
        <button type="button" data-action="clear-local">Reset local</button>
      </div>
    </div>
  `;
  document.body.append(drawer);

  const importInput = document.createElement("input");
  importInput.type = "file";
  importInput.accept = "application/json";
  importInput.hidden = true;
  document.body.append(importInput);

  const metaNode = drawer.querySelector('[data-role="meta"]') as HTMLParagraphElement | null;
  const filterNode = drawer.querySelector('[data-role="filter-target"]') as HTMLSpanElement | null;
  const bodyNode = drawer.querySelector('[data-role="body"]') as HTMLDivElement | null;
  const closeButton = drawer.querySelector('[data-action="close"]') as HTMLButtonElement | null;
  const activeFilterButton = drawer.querySelector('[data-filter="active"]') as HTMLButtonElement | null;
  const allFilterButton = drawer.querySelector('[data-filter="all"]') as HTMLButtonElement | null;

  const sidecar = (): AnnotationSidecar =>
    reviewStoreToSidecar(store, options.sourceMap, {
      wireFile: options.sourceMap.entryFile,
    });

  const tasks = (): AgentTaskExport =>
    exportAgentTasks(store, options.sourceMap, {
      workspaceRoot: options.workspaceRoot,
    });

  const persist = (): void => {
    if (storage && storageKey) {
      storage.setItem(storageKey, JSON.stringify(sidecar()));
    }
    window.dispatchEvent(
      new CustomEvent("wirespec.review.storeChanged", {
        detail: {
          store,
          sidecar: sidecar(),
          tasks: tasks(),
        },
      }),
    );
  };

  const setStore = (nextStore: ReviewStore): void => {
    store = relinkStoreAgainstSourceMap(nextStore, options.sourceMap);
    render();
    persist();
  };

  const focusTarget = (targetId: string): void => {
    highlightedElement?.classList.remove("ws-review-target-highlight");
    const target = document.querySelector(selectorForTarget(targetId)) as HTMLElement | null;
    if (!target) {
      highlightedElement = null;
      return;
    }
    target.scrollIntoView({ block: "center", behavior: "smooth" });
    target.classList.add("ws-review-target-highlight");
    highlightedElement = target;
    window.setTimeout(() => {
      target.classList.remove("ws-review-target-highlight");
      if (highlightedElement === target) {
        highlightedElement = null;
      }
    }, 1200);
  };

  const currentThreads = (): ReviewThread[] =>
    store.threads.filter((thread) => {
      if (filterTargetId && thread.target.targetId !== filterTargetId) {
        return false;
      }
      if (!showClosed && (thread.status === "resolved" || thread.status === "wontfix")) {
        return false;
      }
      return true;
    });

  const renderThreadCard = (thread: ReviewThread): string => {
    const uri = editorUri(options.sourceMap, thread, options.workspaceRoot);
    const targetLabel = labelForTarget(options.sourceMap, thread.target.targetId);
    const summary = summarizeThread(thread);
    const body = latestMessage(thread);
    const variant = thread.target.variantKey
      ? `<span class="ws-review-pill">${escapeHtml(thread.target.variantKey)}</span>`
      : "";
    const orphaned = thread.orphaned
      ? `<p class="ws-review-thread-orphaned">Target needs relinking.</p>`
      : "";

    return `
      <article class="ws-review-thread-card" data-thread-id="${escapeHtml(thread.id)}" data-orphaned="${thread.orphaned ? "true" : "false"}">
        <div class="ws-review-thread-head">
          <div>
            <h3 class="ws-review-thread-title">${escapeHtml(summary)}</h3>
            <p class="ws-review-thread-target">${escapeHtml(scopeLabel(thread.target.scope))} · ${escapeHtml(targetLabel)}</p>
          </div>
          <div class="ws-review-thread-meta">
            <span class="ws-review-severity-pill" data-severity="${escapeHtml(thread.severity)}">${escapeHtml(thread.severity)}</span>
          </div>
        </div>
        <p>${escapeHtml(body)}</p>
        <div class="ws-review-thread-meta">
          <span class="ws-review-status-pill">${escapeHtml(thread.status)}</span>
          ${variant}
        </div>
        ${orphaned}
        <div class="ws-review-thread-actions">
          <button type="button" data-action="focus-target" data-thread-id="${escapeHtml(thread.id)}">Focus target</button>
          ${uri ? `<a href="${escapeHtml(uri)}">Open source</a>` : ""}
          <button type="button" data-action="toggle-status" data-thread-id="${escapeHtml(thread.id)}">${escapeHtml(statusActionLabel(thread))}</button>
        </div>
      </article>
    `;
  };

  const renderDrawer = (): void => {
    if (!metaNode || !filterNode || !bodyNode || !activeFilterButton || !allFilterButton) {
      return;
    }
    const counts = reviewCounts(store);
    metaNode.textContent = `${counts.active} active · ${counts.total} total`;
    filterNode.textContent = filterTargetId
      ? `Filtered to ${labelForTarget(options.sourceMap, filterTargetId)}`
      : "";
    activeFilterButton.setAttribute("aria-pressed", showClosed ? "false" : "true");
    allFilterButton.setAttribute("aria-pressed", showClosed ? "true" : "false");

    const entries = currentThreads();
    bodyNode.innerHTML = entries.length
      ? entries.map(renderThreadCard).join("")
      : `<p class="ws-review-empty">No threads in this view.</p>`;
  };

  const clearPins = (): void => {
    document.querySelectorAll(".ws-review-pin").forEach((node) => node.remove());
  };

  const renderPins = (): void => {
    clearPins();
    const counts = new Map<string, number>();
    for (const thread of store.threads) {
      if (thread.status === "resolved" || thread.status === "wontfix") {
        continue;
      }
      const previous = counts.get(thread.target.targetId) ?? 0;
      counts.set(thread.target.targetId, previous + 1);
    }

    for (const [targetId, count] of counts.entries()) {
      const target = document.querySelector(selectorForTarget(targetId)) as HTMLElement | null;
      if (!target) {
        continue;
      }
      const pin = makeButton(String(count));
      pin.className = "ws-review-pin";
      pin.title = `${count} active review ${count === 1 ? "thread" : "threads"}`;
      pin.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        controller.openDrawer(targetId);
        focusTarget(targetId);
      });
      target.append(pin);
    }
  };

  const render = (): void => {
    threadsButton.textContent = `Threads (${activeThreadCount(store)})`;
    drawer.classList.toggle("is-open", drawerOpen);
    renderDrawer();
    renderPins();
  };

  const onDraftSubmitted = (event: Event): void => {
    const detail = (event as CustomEvent<ReviewDraft>).detail;
    const thread = createReviewThreadFromDraft(detail, options.sourceMap, {
      authorId: options.authorId,
      authorRole: options.authorRole,
      variantKey,
    });
    setStore(addThread(store, thread));
    controller.openDrawer(detail.targetId);
    focusTarget(detail.targetId);
  };

  const onDrawerBodyClick = (event: MouseEvent): void => {
    const rawTarget = event.target instanceof HTMLElement ? event.target : null;
    const action = rawTarget?.getAttribute("data-action");
    const threadId = rawTarget?.getAttribute("data-thread-id");
    if (!action || !threadId) {
      return;
    }
    const thread = store.threads.find((entry) => entry.id === threadId);
    if (!thread) {
      return;
    }
    if (action === "focus-target") {
      focusTarget(thread.target.targetId);
      return;
    }
    if (action === "toggle-status") {
      setStore(updateThreadStatus(store, thread.id, nextStatus(thread)));
    }
  };

  const onImportChange = async (): Promise<void> => {
    const file = importInput.files?.[0];
    if (!file) {
      return;
    }
    try {
      const parsed = JSON.parse(await file.text()) as AnnotationSidecar;
      setStore(sidecarToReviewStore(parsed, options.sourceMap));
      drawerOpen = true;
      render();
    } catch {
      // ignore invalid imports in the reference runtime
    } finally {
      importInput.value = "";
    }
  };

  const onDrawerClick = (event: MouseEvent): void => {
    const rawTarget = event.target instanceof HTMLElement ? event.target : null;
    const action = rawTarget?.getAttribute("data-action");
    if (!action) {
      return;
    }
    if (action === "close") {
      controller.closeDrawer();
      return;
    }
    if (action === "export-annotations") {
      downloadJson(`${options.sourceMap.documentId}.annotations.json`, sidecar());
      return;
    }
    if (action === "export-tasks") {
      downloadJson(`${options.sourceMap.documentId}.agent-tasks.json`, tasks());
      return;
    }
    if (action === "import") {
      importInput.click();
      return;
    }
    if (action === "clear-local") {
      if (storage && storageKey) {
        storage.removeItem(storageKey);
      }
      setStore(createEmptyReviewStore(options.sourceMap.documentId, screenId));
    }
  };

  threadsButton.addEventListener("click", () => {
    drawerOpen = !drawerOpen;
    if (drawerOpen && !filterTargetId) {
      filterTargetId = undefined;
    }
    render();
  });
  closeButton?.addEventListener("click", () => controller.closeDrawer());
  activeFilterButton?.addEventListener("click", () => {
    showClosed = false;
    render();
  });
  allFilterButton?.addEventListener("click", () => {
    showClosed = true;
    render();
  });
  bodyNode?.addEventListener("click", onDrawerBodyClick);
  drawer.addEventListener("click", onDrawerClick);
  const onImportInputChange = (): void => {
    void onImportChange();
  };
  const onKeydown = (event: KeyboardEvent): void => {
    if (event.key === "Escape" && drawerOpen) {
      controller.closeDrawer();
    }
  };

  importInput.addEventListener("change", onImportInputChange);
  window.addEventListener("wirespec.review.draftSubmitted", onDraftSubmitted as EventListener);
  document.addEventListener("keydown", onKeydown);

  const controller: ReviewRuntimeController = {
    dispose: () => {
      cleanupOverlay();
      clearPins();
      drawer.remove();
      importInput.remove();
      threadsButton.remove();
      bodyNode?.removeEventListener("click", onDrawerBodyClick);
      drawer.removeEventListener("click", onDrawerClick);
      importInput.removeEventListener("change", onImportInputChange);
      window.removeEventListener("wirespec.review.draftSubmitted", onDraftSubmitted as EventListener);
      document.removeEventListener("keydown", onKeydown);
      const runtimeWindow = window as Window & { __WIRESPEC_REVIEW__?: ReviewRuntimeController };
      if (runtimeWindow.__WIRESPEC_REVIEW__ === controller) {
        delete runtimeWindow.__WIRESPEC_REVIEW__;
      }
    },
    getStore: () => store,
    getSidecar: () => sidecar(),
    getAgentTasks: () => tasks(),
    openDrawer: (targetId?: string) => {
      filterTargetId = targetId;
      drawerOpen = true;
      render();
    },
    closeDrawer: () => {
      drawerOpen = false;
      render();
    },
    replaceStore: (nextStore: ReviewStore) => {
      setStore(nextStore);
    },
  };

  const runtimeWindow = window as Window & { __WIRESPEC_REVIEW__?: ReviewRuntimeController };
  runtimeWindow.__WIRESPEC_REVIEW__ = controller;

  render();
  persist();
  return controller;
}
